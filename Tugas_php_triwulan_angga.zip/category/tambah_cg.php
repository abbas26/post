<html>
	<head>
		<title>Tambah Data</title>
		
	</head>
	<body>
		<form action="proses_tambah_cg.php" method="POST">
	<table>
	<tr>
		<td><label for="nama">Name</label></td>
		<td>:</td>
		<td><input type="text" name="nama" id="nama"></td>
	</tr>
	<tr>			
		<td></td><td></td><td><input type="submit" value="submit"></td>
	</tr>
</table>
		</form>
	</body>
</html>
